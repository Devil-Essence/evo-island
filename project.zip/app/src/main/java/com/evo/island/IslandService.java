package com.evo.island;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Keeps the notch floating over other apps and mirrors what Evo is doing. */
public class IslandService extends Service {
    private WindowManager wm;
    private IslandView view;
    private volatile boolean running;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (view == null) start();
        return START_STICKY;
    }

    private void start() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("evo", "Evo Island", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, "evo")
                .setContentTitle("Evo Island is running")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build();
        startForeground(1, n);

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = new IslandView(this);
        view.setOnTap(() -> {
            Intent t = new Intent(this, TalkActivity.class);
            t.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(t);
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = statusBarHeight() + Math.round(4 * getResources().getDisplayMetrics().density);
        wm.addView(view, lp);

        running = true;
        new Thread(this::poll, "evo-poll").start();
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private void poll() {
        while (running) {
            String state = "offline", text = "";
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:8765/state").openConnection();
                c.setConnectTimeout(400);
                c.setReadTimeout(600);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close();
                JSONObject j = new JSONObject(sb.toString());
                state = j.optString("state", "idle");
                text = j.optString("text", "");
            } catch (Exception e) {
                // Evo is not running in Termux: show the island as offline
            }
            final String s = state, t = text;
            ui.post(() -> {
                if (view != null) view.setState(s, t);
            });
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        if (view != null) {
            wm.removeView(view);
            view = null;
        }
        super.onDestroy();
    }
}
