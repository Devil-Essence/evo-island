package com.evo.island;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** The notch: a black pill with a glowing ring and sound bars that grows into a card while Evo speaks. */
public class IslandView extends View {
    static final int GREEN = 0xFF3DFFA0, PINK = 0xFFFF4FA3;
    private static final float[] VARY = {0.85f, 0.55f, 1f, 0.7f};

    private final float dp;
    private final float compactW, compactH, wideW, wideH;
    private final long t0 = System.nanoTime();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint label = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint body = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private String state = "offline";
    private String text = "";
    private float progress = 0f; // 0 = small pill, 1 = big card
    private ValueAnimator anim;
    private StaticLayout layout;
    private String layoutText = "";
    private Runnable onTap;

    public IslandView(Context context) {
        super(context);
        DisplayMetrics m = context.getResources().getDisplayMetrics();
        dp = m.density;
        compactW = 150 * dp;
        compactH = 38 * dp;
        wideW = Math.min(358 * dp, m.widthPixels - 32 * dp);
        wideH = 150 * dp;
        fill.setColor(Color.BLACK);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(dp);
        ring.setStyle(Paint.Style.STROKE);
        label.setColor(GREEN);
        label.setTypeface(Typeface.MONOSPACE);
        label.setTextSize(11 * dp);
        label.setLetterSpacing(0.2f);
        body.setColor(0xFFF2F2F2);
        body.setTextSize(15 * dp);
        body.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
    }

    public void setOnTap(Runnable r) {
        onTap = r;
    }

    public void setState(String s, String t) {
        state = s;
        text = t == null ? "" : t;
        float target = "speaking".equals(s) ? 1f : 0f;
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(progress, target);
        anim.setDuration(450);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            requestLayout();
            invalidate();
        });
        anim.start();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(Math.round(lerp(compactW, wideW, progress)),
                Math.round(lerp(compactH, wideH, progress)));
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static int mix(int a, int b, float t) {
        return Color.rgb((int) lerp(Color.red(a), Color.red(b), t),
                (int) lerp(Color.green(a), Color.green(b), t),
                (int) lerp(Color.blue(a), Color.blue(b), t));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float t = (System.nanoTime() - t0) / 1e9f;
        boolean offline = "offline".equals(state);
        float r = lerp(19 * dp, 34 * dp, progress);

        rect.set(dp, dp, w - dp, h - dp);
        c.drawRoundRect(rect, r, r, fill);
        edge.setColor("listening".equals(state) ? 0xCCFF4FA3 : 0x26FFFFFF);
        c.drawRoundRect(rect, r, r, edge);

        // ring on the left
        float rad = lerp(12 * dp, 28 * dp, progress);
        float cx = lerp(19 * dp, 46 * dp, progress);
        float cy = lerp(h / 2, 44 * dp, progress);
        float turns = "thinking".equals(state) ? 1f : "idle".equals(state) || offline ? 0.1f : 0.25f;
        float thick = rad * 0.26f;
        ring.setShader(new SweepGradient(0, 0, new int[]{GREEN, PINK, GREEN}, null));
        ring.setStrokeWidth(thick);
        ring.setAlpha(offline ? 80 : 255);
        c.save();
        c.translate(cx, cy);
        c.rotate(t * turns * 360f);
        c.drawCircle(0, 0, rad - thick / 2, ring);
        c.restore();
        dot.setColor("listening".equals(state) ? PINK : GREEN);
        dot.setAlpha(offline ? 80 : 255);
        float pulse = 0.7f + 0.4f * (0.5f + 0.5f * (float) Math.sin(t * 3.9f));
        c.drawCircle(cx, cy, rad * 0.28f * pulse, dot);
        if (progress > 0.05f) { // little satellite while speaking
            dot.setColor(Color.WHITE);
            dot.setAlpha((int) (255 * progress));
            c.save();
            c.translate(cx, cy);
            c.rotate(t * 163f);
            c.drawCircle(0, -rad, 3 * dp, dot);
            c.restore();
        }

        boolean active = "speaking".equals(state) || "listening".equals(state);
        if (progress < 0.95f) {
            drawBars(c, w - 76 * dp, h / 2, 60 * dp, 22 * dp, 6, 1f - progress, t, active);
        }
        if (progress > 0.05f) {
            drawBars(c, 18 * dp, h - 36 * dp, w - 36 * dp, 40 * dp, 28, progress, t, active);
            label.setAlpha((int) (255 * progress));
            c.drawText("EVO · " + state.toUpperCase(), 88 * dp, 31 * dp, label);
            body.setAlpha((int) (255 * progress));
            int lw = (int) (wideW - 106 * dp);
            if (layout == null || !layoutText.equals(text)) {
                layoutText = text;
                layout = StaticLayout.Builder.obtain(text, 0, text.length(), body, lw)
                        .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).build();
            }
            c.save();
            c.translate(88 * dp, 38 * dp);
            layout.draw(c);
            c.restore();
        }
        if (progress > 0f && progress < 1f || active) postInvalidateOnAnimation();
        else postInvalidateDelayed(40);
    }

    private void drawBars(Canvas c, float left, float midY, float width, float maxH,
                          int count, float alpha, float t, boolean active) {
        float bw = 3 * dp;
        for (int i = 0; i < count; i++) {
            float x = left + i * (width - bw) / (count - 1);
            float amp = active ? 0.2f + 0.8f * Math.abs((float) Math.sin(t * 5.7f + i * 0.9f)) : 0.25f;
            float hh = Math.max(bw, maxH * amp * VARY[i % 4]);
            bar.setColor(mix(GREEN, PINK, i / (float) (count - 1)));
            bar.setAlpha((int) (255 * alpha));
            rect.set(x, midY - hh / 2, x + bw, midY + hh / 2);
            c.drawRoundRect(rect, bw / 2, bw / 2, bar);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) performClick();
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        if (onTap != null) onTap.run();
        return true;
    }
}
