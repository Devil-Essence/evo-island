package com.evo.island;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Opens when you tap the island: type to Evo, press a quick button, or tap the mic. */
public class TalkActivity extends Activity {
    private float d;

    private GradientDrawable shape(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(Math.round(d), stroke);
        g.setCornerRadius(radiusDp * d);
        return g;
    }

    private Button button(String label, int color, int sizeSp) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(sizeSp);
        b.setTextColor(color);
        b.setBackground(shape(Color.TRANSPARENT, color, 22));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(Math.round(16 * d), 0, Math.round(16 * d), 0);
        return b;
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        d = getResources().getDisplayMetrics().density;
        int pad = Math.round(16 * d);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(pad, pad, pad, pad);
        card.setBackground(shape(Color.BLACK, 0x33FFFFFF, 30));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        EditText input = new EditText(this);
        input.setHint("Type to Evo…");
        input.setHintTextColor(0xFF8A8FA6);
        input.setTextColor(0xFFF2F2F2);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setBackground(shape(0xFF0B0B0E, 0x24FFFFFF, 22));
        input.setPadding(pad, 0, pad, 0);
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(0, Math.round(44 * d), 1f);
        row.addView(input, inLp);
        Button send = button("Send", IslandView.GREEN, 14);
        Button mic = button("Mic", IslandView.PINK, 14);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Math.round(44 * d));
        bLp.leftMargin = Math.round(8 * d);
        row.addView(send, bLp);
        row.addView(mic, bLp);
        card.addView(row);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        String[][] quick = {
                {"News", "What's the news?"}, {"My plan", "What's my plan for today?"},
                {"Light on", "turn on the flashlight"}, {"Light off", "turn off the flashlight"},
                {"YouTube", "open youtube"}};
        for (String[] q : quick) {
            Button chip = button(q[0], 0xFFD6D8E4, 13);
            chip.setOnClickListener(v -> say(q[1]));
            LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, Math.round(34 * d));
            cLp.rightMargin = Math.round(8 * d);
            chips.addView(chip, cLp);
        }
        scroll.addView(chips);
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sLp.topMargin = Math.round(10 * d);
        card.addView(scroll, sLp);

        send.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (!q.isEmpty()) say(q);
        });
        input.setOnEditorActionListener((v, id, e) -> {
            send.performClick();
            return true;
        });
        mic.setOnClickListener(v -> post("/talk", ""));

        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(pad / 2, 0, pad / 2, 0);
        frame.addView(card, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(frame);

        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        w.setGravity(Gravity.TOP);
        WindowManager.LayoutParams wlp = w.getAttributes();
        wlp.y = Math.round(56 * d);
        w.setAttributes(wlp);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        input.requestFocus();
    }

    private void say(String text) {
        post("/say", text);
    }

    /** Sends a message to Evo running in Termux (this phone only), then closes. */
    private void post(String path, String body) {
        final android.content.Context app = getApplicationContext();
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:8765" + path).openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("X-Evo", "1");
                c.setConnectTimeout(800);
                c.setReadTimeout(1500);
                c.setDoOutput(true);
                try (OutputStream o = c.getOutputStream()) {
                    o.write(body.getBytes("UTF-8"));
                }
                c.getResponseCode();
                c.disconnect();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(app, "Evo isn't running in Termux", Toast.LENGTH_SHORT).show());
            }
        }).start();
        finish();
    }
}
