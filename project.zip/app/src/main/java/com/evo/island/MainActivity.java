package com.evo.island;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Start or stop the floating island, and grant the "display over other apps" permission. */
public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        float d = getResources().getDisplayMetrics().density;
        int pad = Math.round(24 * d);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF08080A);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("Evo Island");
        title.setTextColor(IslandView.GREEN);
        title.setTextSize(30);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("A floating notch for Evo. Keep Evo running in Termux (python evo.py), then start the island here. Tap the island to type, use quick buttons or talk.");
        info.setTextColor(0xFFB5B9CC);
        info.setTextSize(15);
        info.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(info);

        status = new TextView(this);
        status.setTextColor(IslandView.PINK);
        status.setTextSize(14);
        status.setPadding(0, 0, 0, pad / 2);
        root.addView(status);

        Button start = new Button(this);
        start.setText("Start island");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else {
                startForegroundService(new Intent(this, IslandService.class));
            }
        });
        root.addView(start, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button stop = new Button(this);
        stop.setText("Stop island");
        stop.setOnClickListener(v -> stopService(new Intent(this, IslandService.class)));
        root.addView(stop, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText(Settings.canDrawOverlays(this)
                ? "Permission OK. Tap Start island."
                : "Step 1: tap Start island, then allow \"Display over other apps\" for Evo Island.");
    }
}
